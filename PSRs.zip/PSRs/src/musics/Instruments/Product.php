<?php

namespace PuntelFig\SoN_PHP\PSRs\musics\instruments;

class Product
{
    public function retornaNome()
    {
        return 'Piano Digital';
    }
}
