<?php

namespace PuntelFig\SoN_PHP\PSRs\musics\audio;

class Product
{
    public function retornaNome()
    {
        return 'Rádio';
    }
}
