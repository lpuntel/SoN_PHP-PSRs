<?php

namespace PuntelFig\SoN_PHP\PSRs\computers;

class Product
{
    public function retornaNome()
    {
        return 'Notebook';
    }
}
